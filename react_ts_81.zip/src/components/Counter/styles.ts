import styled from "@emotion/styled";

export const CounterWrapper = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 20px;
  min-width: 400px;
  padding: 20px;
  background-color: white;
  border: 2px solid rgb(46, 13, 81);
  border-radius: 18px;
`;

export const ButtonWrapper = styled.div`
  width: 100px;
`;

export const Result = styled.div`
  font-size: 28px;
  font-weight: bold;
  color: rgb(46, 13, 81);
`;
